//SOAP vs REST
//REST APIs : Es un "servicio" que nos brinda recursos en formatos XML y JSON
/*

URL base : Es la url habilitada para hacer request de tipo XHR. Ej.: 

		host : dominio.com
		baseURL : dominio.com / dominio.com/api
		

Funciones/Recursos/EndPoints : Son los dinstintos recursos expresados en forma de path agregado en la url de base. Ej.:

		dominio.com/api/usuarios
		dominio.com/api/direcciones
		dominio.com/api/posteos
		dominio.com/api/fotos


Implementacion : 

	- Prametros : Si admite o no parametros, como se llaman o que reciben. Ej.:  

Funcion : USUARIOS
URL : dominio.com/api/usuarios
Parametros 
	-id : numero
	-nombre : string

Ej.: dominio.com/api/usuarios?id=1&nombre=horacio
	

	- Respuesta : Que te devuele una funcion 

	- Errores : Que tipo de errores pueden aparecer y como manejarlos


JSON.parse(String)
JSON.stringify(Object)



https://jsonplaceholder.typicode.com

1) Ir a pedir un listado de todos los usuarios
2) Cuando traen la respuesta, elegir un usuario aleatorio y sacarle su ID
3) Usando el ID del punto anterior, ir a pedir todos los posts de ese usuario
4) Cuando traen la respuesta de posts , recorrer el array de todos los posteos
5) Por cada post sacarle su ID y pedir todos los comments
6) Mostrar en consola todos los comentarios hechos del usuario elegido

Respuesta correcta : 

10 console.logs con un array de 5 objetos por cada log.  



*/
function ajax(metodo,url,funcionFinal){
	var xhr = new XMLHttpRequest
	xhr.open(metodo,url)
	xhr.addEventListener("load",function(){
		if (xhr.status == 200) {
			funcionFinal(xhr.response)
		}
	})
	xhr.send()
}



//Pyramid of Doom
//Callback of Hell

var id = ajax("get","https://jsonplaceholder.typicode.com/users",function(users){
	var usuarios = JSON.parse(users)
	var id_usuario = usuarios[6].id
	ajax("get","https://jsonplaceholder.typicode.com/posts?userId="+id_usuario,function(posts){
		var posteos = JSON.parse(posts)
		posteos.forEach(function(post){
			var id_post = post.id
			ajax("get","https://jsonplaceholder.typicode.com/comments?postId="+id_post,function(comentarios){
				var comments = JSON.parse(comentarios)
				console.log(comments)
			})
		})
	})
})


//nominatim api : https://wiki.openstreetmap.org/wiki/Nominatim
//Es una API RESTfull que nos permite interactuar con la geolocalizacion

//Geolocation API : navigator.geolocation
//getCurrentPosition(Function callback) : El callback que se ejecuta ya recibe la ubicaciòn de manera automatica

/*
https://nominatim.openstreetmap.org/reverse?format=json&lat=-34.601236&lon=
-58.37740600000001

https://tinyurl.com/ybgfjt7z
*/